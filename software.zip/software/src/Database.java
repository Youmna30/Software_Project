import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;


public class Database {
	
	ArrayList<Game>ScienceTF=new ArrayList<Game>();
	ArrayList<Game>ScienceMCQ=new ArrayList<Game>();
	ArrayList<Game>MathTF=new ArrayList<Game>();
	ArrayList<Game>MathMCQ=new ArrayList<Game>();
	ArrayList<Game>CodeTF=new ArrayList<Game>();
	ArrayList<Game>CodeMCQ=new ArrayList<Game>();
	ArrayList<Game>TechTF=new ArrayList<Game>();
	ArrayList<Game>TechMCQ=new ArrayList<Game>();
	ArrayList<Student>students=new ArrayList<Student>();
	ArrayList<Teacher>teachers=new ArrayList<Teacher>();
	
	public Database()
	  {
		 
		  LoadTrueAndFalseGames("MathTF.txt",MathTF);
		  LoadMCQGames("MathMCQ.txt",MathMCQ);
		  LoadTrueAndFalseGames("ScienceTF.txt",ScienceTF);
		  LoadMCQGames("ScienceMCQ.txt", ScienceMCQ);
		  LoadTrueAndFalseGames("CodingTF.txt", CodeTF);
		  LoadMCQGames("CodingMCQ.txt", CodeMCQ);
		  LoadTrueAndFalseGames("TechnologyTF.txt", TechTF);
		  LoadMCQGames("TechnologyMCQ.txt", TechMCQ);
		  LoadStudents();
		  LoadTeachers();
		  
	  }
	public void AddUser(Student s)
	{
		students.add(s);
		
	}
	public void AddUser(Teacher t)
	{
		teachers.add(t);
	}

  public void LoadTrueAndFalseGames(String FileName,ArrayList<Game> games)
  {
	  try
	  {
	    Scanner  sc=new Scanner(new File(FileName));
	    while(sc.hasNext())
	    {   
	    	
	    	Game g=new Game();
	        g.setName(sc.nextLine());
	    	g.setDescrition(sc.nextLine());
	        g.setNumOfQuestion(sc.nextInt());
		    	sc.nextLine();
	        ArrayList<TrueAndFalse>questions=new ArrayList<TrueAndFalse>();
	    	for(int i=0;i<g.getNumOfQuestion();i++)
	    	{
	    	TrueAndFalse q=new TrueAndFalse() ;
	    	q.setStatment(sc.nextLine());
	    	if(sc.hasNextBoolean())
	    	{
	    		
	    		q.setCorrectAnswer(sc.nextBoolean());
	    		sc.nextLine();
	    		
	    		}
	        questions.add(q);
	    	
	    }
	    	g.setTFQuestions(questions);
	    	games.add(g);
	 
	    
	  }
	    sc.close();
	    for(int i=0;i<games.size();i++)
		  {
	    	
			  for(int j=0; j<games.get(i).getNumOfQuestion(); j++)
			  {
				  if(j==0)
				  {
					//  System.out.println(games.get(i).getName());
			      //		  System.out.println(games.get(i).getDescrition());
				  }
				  //System.out.println(games.get(i).getTFQuestions().get(j).getStatment());
		        }
	     }
			  
	  }
	  catch(Exception e)
	  {
		  System.out.println("82"+e);
	  }
	
  }
  public void LoadMCQGames(String FileName,ArrayList<Game>game)
  {
	  try
	  {
	    Scanner  sc=new Scanner(new File(FileName));
	    ArrayList<String>choices=new ArrayList<String>();
	    while(sc.hasNext())
	    {
	    	Game g=new Game();
	        g.setName(sc.nextLine());
	    	g.setDescrition(sc.nextLine());
	        g.setNumOfQuestion(sc.nextInt());
		    	sc.nextLine();
		    	ArrayList<MCQ> Question = new ArrayList<MCQ>();
		    	for(int i=0;i<g.getNumOfQuestion();i++)
		    	{
	    	         MCQ q=new MCQ() ;
	    	         q.setStatment(sc.nextLine());
	    	       for(int j=0;j<4; j++)
	    		{
	    		choices.add(sc.nextLine());
	    		}
	    	
	    	q.setChoices(choices);
	    	q.setCorrctAnswer(sc.nextInt());
	    	sc.nextLine();
	    	Question.add(q);
		    	}
	    	//game2.add(q);
	   g.setMCQquestions(Question);
	   game.add( g);
	    	
	    }
	    sc.close();
	    for(int i=0;i<game.size();i++)
		  {  
			  for(int j=0;j<game.get(i).getNumOfQuestion();j++)
			  {   
				  if(j==0)
				  {
					  //System.out.println(game.get(i).getName());
					//  System.out.println(game.get(i).getDescrition());
				  }
				  //System.out.println(game.get(i).getMCQquestions().get(j).getStatment());
				  for(int k=j*4;k<((j+1)*4);k++)
				  {
					//  System.out.println(game.get(i).getMCQquestions().get(j).getChoices().get(k));
				  }
			  }
			  
		  }
	    
	  }
	  catch(Exception e)
	  {
		  System.out.println("90 "+e);
	  }
  }

  public void LoadStudents()
  {
	  try{
		  Scanner sc=new Scanner(new File("Students.txt"));
		  while(sc.hasNext()){
			  Student s=new Student();
			  s.setName(sc.nextLine());
			  s.setPassword(sc.nextLine());
			  s.setEmali(sc.nextLine());
			 students.add(s);
			
			  
		  }
		  
		  sc.close();
	  }
	  catch(Exception e){
		  System.out.println(e);
	  }
  }
  
  
  public void LoadTeachers()
  {
	  try{
		  Scanner sc=new Scanner(new File("Teachers.txt"));
		  while(sc.hasNext()){
			  Teacher t=new Teacher();
			  t.setName(sc.nextLine());
			  t.setPassword(sc.nextLine());
			  t.setEmali(sc.nextLine());
			  t.setId(sc.nextLine());
			  teachers.add(t);
			 
			  
		  }
		  
		  sc.close();
	  }
	  catch(Exception e){
		  System.out.println(e);
	  }
  }
  public void SaveStudents()
  {
	  try
	  {
	  Formatter f=new Formatter("Students.txt");
	  for(int i=0;i<students.size();i++)
	  {
		  f.format("%s\n",students.get(i).getName());
		  f.format("%s\n",students.get(i).getPassword());
		  f.format("%s\n",students.get(i).getEmali());
	  }
	  f.close();
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
		  
	  }
  }
  public void SaveTeacher()
  {
	  try
	  {
	  Formatter f=new Formatter("Teachers.txt");
	  for(int i=0;i<teachers.size();i++)
	  {
		  f.format("%s\n",teachers.get(i).getName());
		  f.format("%s\n",teachers.get(i).getPassword());
		  f.format("%s\n",teachers.get(i).getEmali());
		  f.format("%s\n",teachers.get(i).getId());
	  }
	  f.close();
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
		  
	  }
  }
  
  public void  SaveMCQGame(Game game,String category )
  {
	  if(category.equals("Science"))
	  {
		  ScienceMCQ.add(game);	  
		  SaveOnFileMCQ("ScienceMCQ.txt",ScienceMCQ);
	  }
	  else if(category.equals("Math"))
	  {
		  MathMCQ.add(game);
		 SaveOnFileMCQ("MathMCQ.txt", MathMCQ);
	  }
	  else if(category.equals("Technology"))
	  {
		  TechMCQ.add(game);
		  SaveOnFileMCQ("TecMCQ.txt",TechMCQ);
	  }
	  else if(category.equals("Code"))
	  {
		  CodeMCQ.add(game);
		  SaveOnFileMCQ("CodeMCQ.txt", CodeMCQ);
	  }
  }
  public void  SaveTFGame(Game game,String category ) throws FileNotFoundException
  {
	  if(category.equals("Science"))
	  {
		  ScienceTF.add(game);
		  SaveOnFileTF("ScienceTF.txt", ScienceTF);
		  
	  }
	  else if(category.equals("Math"))
	  {
		  MathTF.add(game);
		  SaveOnFileTF("MathTF.txt", MathTF);
	  }
	  else if(category.equals("Technology"))
	  {
		  TechTF.add(game);
		  SaveOnFileTF("TechTF.txt",TechTF);
	  }
	  else if(category.equals("Code"))
	  {
		  CodeTF.add(game);
		  SaveOnFileTF("CodeTF.txt",CodeTF);
	  }
	  
	  
  }
  public void SaveOnFileMCQ(String FileName,ArrayList<Game>games)
  {
	  try
	  {
	  Formatter f=new Formatter(FileName);
	  for(int i=0;i<games.size();i++)
	  {
		  System.out.println(i);
		  System.out.println(games.get(i).getName());
		  f.format("%s\n", games.get(i).getName());
		  f.format("%s\n", games.get(i).getDescrition());
		  f.format("%s\n", games.get(i).getNumOfQuestion());
		  for(int j=0;j<games.get(i).getNumOfQuestion();j++)
		  {
			  f.format("%s\n", games.get(i).getMCQquestions().get(j).getStatment());
			  for(int k=0;k<4;k++)
			  {
				  f.format("%s\n", games.get(i).getMCQquestions().get(j).getChoices().get(k));
			  }
			  f.format("%s\n", games.get(i).getMCQquestions().get(j).getCorrctAnswer());	
		  }
			  
		  
	  }
	  f.close();
	  }
	  catch(Exception e)
	  {
		  System.out.println("321 "+e);
		  
	  }
  }
  public void SaveOnFileTF(String FileName,ArrayList<Game>games)
  {
	  try
	  {
		  Formatter f=new Formatter(FileName);
		  for(int i=0;i<games.size();i++)
		  {
			  f.format("%s\n",games.get(i).getName());
			  f.format("%s\n",games.get(i).getDescrition());
			  f.format("%s\n",games.get(i).getNumOfQuestion());
			  for(int j=0;j<games.get(i).getNumOfQuestion();j++)
			  {
				  f.format("%s\n",games.get(i).getTFQuestions().get(j).getStatment());
				  f.format("%s\n",games.get(i).getTFQuestions().get(j).getCorrectAnswer());
				  
			  }
		  }
		  f.close();
	  }
	  catch(Exception e)
	  {
		  
	  }
  }
  
  
}
