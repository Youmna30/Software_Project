import java.util.ArrayList;
import java.util.Scanner;


public class TeacherHomePage extends HomePage {
	public GameManager gameManager=new GameManager();
   public TeacherHomePage()
   {
		System.out.println("1-Add game");
		System.out.println("2-Try game");
   }
   public void WaitAction(int choice)
   {
	   if(choice==1)
	   {
		   System.out.println("1-MCQ");
		   System.out.println("2-True and false");
		   Scanner sc=new Scanner(System.in);
		   int c=sc.nextInt();
		   sc.nextLine();
		   int number=sc.nextInt();
		   sc.nextLine();
		   String description="";
		   String category="";
		   String name="";
		   if(c==1)
		   {
			   ArrayList<String>statments=new ArrayList<String>();
			   ArrayList<Integer>CorrectAnswer=new ArrayList<Integer>();
			   ArrayList<ArrayList<String>>choices=new ArrayList<ArrayList<String>>();
			   System.out.println("Enter the number of questions");
			   number=sc.nextInt();
			   sc.nextLine();
			   for(int i=0;i<number;i++)
			   {
				   System.out.println("Enter the question");
				   statments.add(sc.nextLine());
				   System.out.println("Enter the choices");
				   choices.add(new ArrayList<String>());
				   for(int j=0;j<4;j++)
				   {
					   choices.get(i).add(sc.nextLine());
				   }
				   System.out.println("Enter the number of the correct choice");
				   CorrectAnswer.add(sc.nextInt());
				   sc.nextLine();
				   
			   }
			   
			   System.out.println("Enter description for this game");
			   description=sc.nextLine();
			   System.out.println("Select category to add this game in");
			   category=sc.nextLine();
			   System.out.println("Choose name to your game");
			   name=sc.nextLine();
			   gameManager.AddGame(statments, CorrectAnswer, choices,category,"MCQ",description,name);
			   
		   }
		   else if(c==2)
		   {
			   ArrayList<String>statments=new ArrayList<String>();
			   ArrayList<Boolean>CorrectAnswer=new ArrayList<Boolean>();
			   for(int i=0;i<number;i++)
			   {
				  // ArrayList<String>statments=new ArrayList<String>();
				   //ArrayList<Integer>CorrectAnswer=new ArrayList<Integer>();
				   System.out.println("Enter the question");
				   statments.add(sc.nextLine());
				   System.out.println("Enter the correct answer");
				   CorrectAnswer.add(sc.nextBoolean());
				   sc.nextLine();
				   
			   }
			   
			   System.out.println("Enter description for this game");
			   description=sc.nextLine();
			   System.out.println("Select category to add this game in");
			   category=sc.nextLine();
			   System.out.println("Choose name to your game");
			   name=sc.nextLine();
			   gameManager.AddTFGame(statments, CorrectAnswer, category, description,name);
			   
		   }
		   
	   }
	   else if(choice==2)
	   {
		   
	   }
   }
   
   
}
