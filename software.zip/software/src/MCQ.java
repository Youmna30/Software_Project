import java.util.ArrayList;


public class MCQ extends Question {
   private ArrayList<String> choices=new ArrayList<String>();
   private int UserAnswer;
   private int CorrctAnswer;
   private String statment;
  
public ArrayList<String> getChoices() {
	return choices;
}

public void setStatment(String statment) {
	this.statment = statment;
}

public String getStatment() {
	return statment;
}


public void setChoices(ArrayList<String> choices) {
	this.choices=choices;
}
public int getUserAnswer() {
	return UserAnswer;
}
public void setUserAnswer(int userAnswer) {
	UserAnswer = userAnswer;
}
public int getCorrctAnswer() {
	return CorrctAnswer;
}
public void setCorrctAnswer(int correctAnswer) {
	CorrctAnswer = correctAnswer;
}


}
