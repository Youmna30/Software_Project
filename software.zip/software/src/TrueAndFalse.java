
public class TrueAndFalse extends Question {

	private boolean UserAnswer;
	private boolean CorrectAnswer;
	private String statment;
	public boolean getUserAnswer() {
		return UserAnswer;
	}
	public void setStatment(String statment) {
		this.statment = statment;
	}
	
	public String getStatment() {
		return statment;
	}
	public void setUserAnswer(boolean userAnswer) {
		UserAnswer = userAnswer;
	}
	public boolean getCorrectAnswer() {
		return CorrectAnswer;
	}
	public void setCorrectAnswer(boolean i) {
		CorrectAnswer = i;
	}
	
	
}
