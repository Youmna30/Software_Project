
public class HomePage {
	
	public HomePage GetNextpage()
	{
		return (new HomePage());
	}
	public void WaitAction(int choice)
	{
		
	}
public void WaitSelectedGame(String NG)
{
}
}
