import java.util.ArrayList;

public class Student extends User {
     public	ArrayList<Game> PlayedGames;
     public void setPlayedGame(Game g)
     {
    	 PlayedGames.add(g);
    	 
     }
     public ArrayList<Game> getPlayedGame()
     {
    	 return PlayedGames;
     }
     
     
	
	

}
