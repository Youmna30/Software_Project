import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

public class RegisterationManager {
	Database db=new Database();
	VerificationManager v=new VerificationManager();
	
	public boolean MakeRegisteration(StudentRegisterationForm f)
	{
		
	    if(v.VerfiyStudent(f))
		{
	    	Student s=new Student();
			s.setName(f.getName());
			s.setEmali(f.getEmail());
			s.setPassword(f.getPassword());
			db.AddUser(s);
			db.SaveStudents();
			return true;
		}
		
	    else 
	    {
	    	return false;
	    }
	
		
		
	}
	public boolean MakeRegisteration(TeacherRegisterationForm f)
	{

	    if(v.VerifyTeacher(f))
		{
	    	Teacher t=new Teacher();
			t.setName(f.getName());
			t.setEmali(f.getEmail());
			t.setPassword(f.getPassword());
			t.setId(f.getId());
			db.AddUser(t);
			db.SaveTeacher();
			return true;
		}
		
	    else 
	    {
	    	return false;
	    }
	
	}
	
}

