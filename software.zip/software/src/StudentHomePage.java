import java.util.ArrayList;


public class StudentHomePage extends HomePage {
	GameManager obj = new GameManager();
	String type;
    String Category;
    ArrayList<ArrayList<String>> games= new ArrayList<ArrayList<String>>();
	public StudentHomePage()
	{
		System.out.println("1-Science");
		System.out.println("2-Math");
		System.out.println("3-Coding");
		System.out.println("4-Technology");
	}


	public void WaitAction(int choice)
	{
		
		System.out.println("wait action");
		if(choice == 1)
		{
			Category="Science";
			games=obj.DisplayGame("Science");
			System.out.println(obj.DisplayGame("Science"));
		}
		else if(choice == 2)
		{
			Category="Math";
			games=obj.DisplayGame("Math");
			System.out.println(obj.DisplayGame("Math"));
		}
		else if(choice == 3)
		{
			Category="Code";
			games=obj.DisplayGame("Code");
			System.out.println(obj.DisplayGame("Code"));
		}
		else if(choice ==4)
		{
			Category="Tech";
			games=obj.DisplayGame("Tech");
			System.out.println(obj.DisplayGame("Tech"));
		}
		
	}
    public void WaitSelectedGame(String NameOfGame)
    {
    	if(games.get(0).indexOf(NameOfGame)!=-1)
    		{
    		System.out.println("xxx");
    		type="TF";
    		System.out.println("hhhhh");
              
    		}
    	else
    	{
    	
    		type="MCQ";
    		
    	}
    	obj.PlayGame(NameOfGame, type, Category);
    	
    }

	
}
