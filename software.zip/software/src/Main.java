import java.util.Scanner;


public class Main {

	
	//public static Database db=new Database();
	
	public static void main(String[] args) {
	/*  VerificationManager vm=new VerificationManager();
	  vm.EmailFormatIsRight("yomnamansour@gmail.com");
		db.LoadAll();
		GameManager x = new GameManager ();
		x.PlayGame("general science knowledge", "MCQ", "Science",db);
		//for(int i=0; i<3; i++)
			//System.out.println(db.game1.get(i).getStatment()+"  "+db.game1.get(i).getCorrectAnswer());
		*/
		int choice;
		Scanner sc=new Scanner(System.in);
		LoginPage lp=new LoginPage();
		lp.WaitAction(sc.nextLine());
		//HomePage hp=lp.GetNextPage();
		//**StudentHomePage shp = new StudentHomePage();
		HomePage shp=lp.GetNextPage();
		choice = sc.nextInt();
		shp.WaitAction(choice);
		System.out.println("Select from here");
		String NG;
		NG=sc.nextLine();
		NG=sc.nextLine();

       shp.WaitSelectedGame(NG);
        //GameManager obj = new GameManager();
	}

}
