
public class StudentRegisterationForm extends Form{
	private String ConfirmedPassword;
	private String name;
    private String number;
    
	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getConfirmedPassword() {
		return ConfirmedPassword;
	}

	public void setConfirmedPassword(String confirmedPassword) {
		ConfirmedPassword = confirmedPassword;
	}


	

}
