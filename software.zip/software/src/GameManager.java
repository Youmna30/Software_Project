import java.util.ArrayList;
import java.util.Scanner;


public class GameManager {
	 Database DB= new Database();

   public void PlayGame(String name,String type,String category){
	
	   int idx = 0;
	   int num;
	   Scanner in=new Scanner(System.in);
	if(type.equals("MCQ"))
	{
		if(category.equals("Science"))
		{
			
			for(int j=0 ;j <DB.ScienceMCQ.size();j++)
			{
				if(DB.ScienceMCQ.get(j).getName().equals(name));
				{
					idx=j;
					//idx=DB.ScienceMCQ.indexOf(DB.ScienceMCQ.get(j).getName());
				}
				
				
			//System.out.println(idx);
			/// kont 3yza a load el game de w atl3 m3lomatha
			System.out.println(DB.ScienceMCQ.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			}
		    num=in.nextInt();
			int answer;
			if(num==1){
				for(int i=0; i<DB.ScienceMCQ.get(idx).getNumOfQuestion(); i++)
				{
				System.out.println(DB.ScienceMCQ.get(idx).getMCQquestions().get(i).getStatment());
				//for(int k=i*4;k<((i+1)*4);k++)
				for(int j=0;j<4;j++)
				  {
					System.out.println(DB.ScienceMCQ.get(idx).getMCQquestions().get(i).getChoices().get(j));		
					}
				
				System.out.println("Enter the number of Answer ");
				answer=in.nextInt();
				if(DB.ScienceMCQ.get(idx).getMCQquestions().get(i).getCorrctAnswer()==answer)
				{
					DB.ScienceMCQ.get(idx).setScore(DB.ScienceMCQ.get(idx).getScore()+1);
				}
				else
				{
					System.out.println("Wrong Answer");
				}
				
				System.out.println(DB.ScienceMCQ.get(idx).getScore());
				}	
			}
			else{
				while(in.nextInt()!=1){
					num=in.nextInt();
				}
			}
		}
		
		else if(category.equals("Tech"))
		{
			for(int j=0 ;j <DB.TechMCQ.size();j++)
			{
				if(DB.TechMCQ.get(j).getName()==name)
				{idx=DB.TechMCQ.indexOf(DB.TechMCQ.get(j).getName());}
				}
			//System.out.println(idx);
			/// kont 3yza a load el game de w atl3 m3lomatha
			System.out.println(DB.TechMCQ.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			
		    num=in.nextInt();
			int answer;
			if(num==1){
				for(int i=0; i<DB.TechMCQ.get(idx).getNumOfQuestion(); i++)
				{
				System.out.println(DB.TechMCQ.get(idx).getMCQquestions().get(i).getStatment());
				for(int k=i*4;k<((i+1)*4);k++)
				  {
					System.out.println(DB.TechMCQ.get(idx).getMCQquestions().get(i).getChoices().get(k));	
					}
				
				System.out.println("Enter the number of Answer ");
				answer=in.nextInt();
				if(DB.TechMCQ.get(idx).getMCQquestions().get(i).getCorrctAnswer()==answer)
				{
					DB.TechMCQ.get(idx).setScore(DB.TechMCQ.get(idx).getScore()+1);
				}

				else
				{
					System.out.println("Wrong Answer");
				}
				System.out.println(DB.TechMCQ.get(idx).getScore());
				}
			
		}
			else{
				while(in.nextInt()!=1){
					num=in.nextInt();
				}
			}
		}
		else if(category.equals("Math"))
		{
			for(int j=0 ;j <DB.MathMCQ.size();j++)
			{
				if(DB.MathMCQ.get(j).getName()==name)
				{
					idx=DB.MathMCQ.indexOf(DB.MathMCQ.get(j).getName());
					}
				}
			//System.out.println(idx);
			/// kont 3yza a load el game de w atl3 m3lomatha
			System.out.println(DB.MathMCQ.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			
		    num=in.nextInt();
			int answer;
			if(num==1){
				for(int i=0; i<DB.MathMCQ.get(idx).getNumOfQuestion(); i++){
				System.out.println(DB.MathMCQ.get(idx).getMCQquestions().get(i).getStatment());
				for(int k=i*4;k<((i+1)*4);k++)
				  {
					System.out.println(DB.MathMCQ.get(idx).getMCQquestions().get(i).getChoices().get(k));		
					}
				
				System.out.println("Enter the number of Answer ");
				answer=in.nextInt();
				if(DB.MathMCQ.get(idx).getMCQquestions().get(i).getCorrctAnswer()==answer)
				{
					DB.MathMCQ.get(idx).setScore(DB.MathMCQ.get(idx).getScore()+1);
				
				}
				else
				{
					System.out.println("Wrong Answer");
				}
				System.out.println(DB.MathMCQ.get(idx).getScore());
				}
			}
				else{
					while(in.nextInt()!=1){
						num=in.nextInt();
					}
			
		
		
		}
		}
		else if(category.equals("Code"))
		{
			for(int j=0 ;j <DB.CodeMCQ.size();j++)
			{
				if(DB.CodeMCQ.get(j).getName()==name)
				{
					idx=DB.CodeMCQ.indexOf(DB.CodeMCQ.get(j).getName());
					}
				}
			//System.out.println(idx);
			/// kont 3yza a load el game de w atl3 m3lomatha
			System.out.println(DB.CodeMCQ.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			
		    num=in.nextInt();
			int answer;
			if(num==1){
				for(int i=0; i<DB.CodeMCQ.get(idx).getNumOfQuestion(); i++)
				{
				System.out.println(DB.CodeMCQ.get(idx).getMCQquestions().get(i).getStatment());
				for(int k=i*4;k<((i+1)*4);k++)
				  {
					System.out.println(DB.CodeMCQ.get(idx).getMCQquestions().get(i).getChoices().get(k));		
					}
				
				System.out.println("Enter the number of Answer ");
				answer=in.nextInt();
				if(DB.CodeMCQ.get(idx).getMCQquestions().get(i).getCorrctAnswer()==answer)
				{
					DB.CodeMCQ.get(idx).setScore(DB.CodeMCQ.get(idx).getScore()+1);
				
				}
				else
				{
					System.out.println("Wrong Answer");
				}
				System.out.println(DB.CodeMCQ.get(idx).getScore());
				}
			}	
				else{
					while(in.nextInt()!=1)
					{
						num=in.nextInt();
					}
					
		
				}
		}
		
	}
	
	else if(type.equals("TF")){
		if(category.equals("Science")){
			for(int j=0 ;j <DB.ScienceTF.size();j++)
			{
				if(DB.ScienceTF.get(j).getName()==name)
				{idx=DB.ScienceTF.indexOf(DB.ScienceTF.get(j).getName());}
				}
			//idx=DB.ScienceTF.indexOf(name);
			System.out.println(DB.ScienceTF.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			num =in.nextInt();
			if(num==1){
				for(int i=0; i<DB.ScienceTF.get(idx).getNumOfQuestion(); i++){// I guess en el num of Q will be handled in database or something
					System.out.println(DB.ScienceTF.get(idx).getTFQuestions().get(i).getStatment());
					System.out.println("Enter true or false");
					boolean answer=in.nextBoolean();
					if(DB.ScienceTF.get(idx).getTFQuestions().get(i).getCorrectAnswer()== answer)
					{
						DB.ScienceTF.get(idx).setScore(DB.ScienceTF.get(idx).getScore()+1);
					}
					else
					{
						System.out.println("Wrong Answer");
					}
					System.out.println(DB.ScienceTF.get(idx).getScore());
				}
			}
		}
		else if(category.equals("Math")){
			for(int j=0 ;j <DB.MathTF.size();j++)
			{
				if(DB.MathTF.get(j).getName()==name)
				{idx=DB.MathTF.indexOf(DB.MathTF.get(j).getName());}
				}
			//idx=DB.ScienceTF.indexOf(name);
			System.out.println(DB.MathTF.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			num =in.nextInt();
			if(num==1){
				for(int i=0; i<DB.MathTF.get(idx).getNumOfQuestion(); i++){// I guess en el num of Q will be handled in database or something
					System.out.println(DB.MathTF.get(idx).getTFQuestions().get(i).getStatment());
					System.out.println("Enter true or false");
					boolean answer=in.nextBoolean();
					if(DB.MathTF.get(idx).getTFQuestions().get(i).getCorrectAnswer()==answer){
						DB.MathTF.get(idx).setScore(DB.MathTF.get(idx).getScore()+1);
					}
					else
					{
						System.out.println("Wrong Answer");
					}
					System.out.println(DB.MathTF.get(idx).getScore());
				}
			}
		}
		else if(category.equals("Tech"))
		{
			for(int j=0 ;j <DB.TechTF.size();j++)
			{
				if(DB.TechTF.get(j).getName()==name)
				{idx=DB.TechTF.indexOf(DB.TechTF.get(j).getName());}
				}
			//idx=DB.ScienceTF.indexOf(name);
			System.out.println(DB.TechTF.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			num =in.nextInt();
			if(num==1){
				for(int i=0; i<DB.TechTF.get(idx).getNumOfQuestion(); i++){// I guess en el num of Q will be handled in database or something
					System.out.println(DB.TechTF.get(idx).getTFQuestions().get(i).getStatment());
					System.out.println("Enter true or false");
					boolean answer=in.nextBoolean();
					if(DB.TechTF.get(idx).getTFQuestions().get(i).getCorrectAnswer()==answer){
						DB.TechTF.get(idx).setScore(DB.TechTF.get(idx).getScore()+1);
					}
					else
					{
						System.out.println("Wrong Answer");
					}
					System.out.println(DB.TechTF.get(idx).getScore());
				}
			}
		}
		else if(category.equals("Code"))
		{
			for(int j=0 ;j <DB.CodeTF.size();j++)
			{
				if(DB.TechTF.get(j).getName()==name)
				{idx=DB.TechTF.indexOf(DB.CodeTF.get(j).getName());}
				}
			//idx=DB.ScienceTF.indexOf(name);
			System.out.println(DB.CodeTF.get(idx).getDescrition());
			System.out.println("To start playing press 1");
			num =in.nextInt();
			if(num==1){
				for(int i=0; i<DB.CodeTF.get(idx).getNumOfQuestion(); i++){// I guess en el num of Q will be handled in database or something
					System.out.println(DB.CodeTF.get(idx).getTFQuestions().get(i).getStatment());
					System.out.println("Enter true or false");
					boolean answer=in.nextBoolean();
					if(DB.CodeTF.get(idx).getTFQuestions().get(i).getCorrectAnswer()==answer){
						
						DB.CodeTF.get(idx).setScore(DB.CodeTF.get(idx).getScore()+1);
					}
					else
					{
						System.out.println("Wrong Answer");
					}
					System.out.println(DB.CodeTF.get(idx).getScore());
				}
			}
		}
	
	}
   }

   public void AddGame(ArrayList<String>statments,ArrayList<Integer>CorrectAnswer,ArrayList<ArrayList<String>>choices,
		   String category,String type,String description,String name)
   {
	   
	   Scanner sc=new Scanner(System.in);
	  Game game=new  Game();
	   if(type.equals("MCQ"))
	   {
		   game.setName(name);
		   game.setDescrition(description);
		   ArrayList<MCQ> questions=new ArrayList<MCQ>();
		   for(int i=0;i<statments.size();i++)
		   {
			   MCQ q=new MCQ();
			   q.setStatment(statments.get(i));
			   q.setCorrctAnswer(CorrectAnswer.get(i));
			   q.setChoices(choices.get(i));
			   questions.add(q);
			   
		   }
		   game.setMCQquestions(questions);
		   game.setNumOfQuestion(questions.size());
		   DB.SaveMCQGame(game,category);
	   }
	   
	   
   }
   
   public void AddTFGame(ArrayList<String> statments,ArrayList<Boolean> CorrectAnswers, String category,
			  String description,String name)
	  {
	   Game game=new  Game();
		  game.setName(name);
		  game.setDescrition(description);
		  
		  ArrayList<TrueAndFalse> questions=new ArrayList<TrueAndFalse>();
		  for(int i=0;i<statments.size();i++)
		  { 
			  TrueAndFalse q=new TrueAndFalse();
			  q.setStatment(statments.get(i));
			  q.setCorrectAnswer(CorrectAnswers.get(i));
			  questions.add(q);
		  }
		  game.setNumOfQuestion(questions.size());
		  game.setTFQuestions(questions);
		  try{DB.SaveTFGame(game,category );}
		  catch(Exception e){
			  System.out.println("364 "+e);
		  }
	  }
   
	   /*if(Type.equals("MCQ"))
	   {
		   ArrayList<MCQ>questions=new ArrayList<MCQ>();
		   for(int i=0;i<NumOfQuestions;i++)
		   {
			   MCQ q=new MCQ();
			   System.out.println("Enter the statment ");
			   q.setStatment(sc.nextLine());        //statment
			   ArrayList<String>choices=new ArrayList<String>();
			   System.out.println("Enter the choices");
			   for(int j=0;j<3;j++)
			   {
				   choices.add(sc.nextLine());
			   }
			   q.setChoices(choices);
			   System.out.println("Enter the correct answer");
			   q.setCorrctAnswer(sc.nextInt());
			   questions.add(q);
		   }
		   g.setMCQquestions(questions);
		   System.out.println("Enter name for the game");
		   g.setName(sc.nextLine());
		   System.out.println("Enter description to the game");
		   g.setDescrition(sc.nextLine());
		   
	   }
	   if(Type.equals("TrueAndFalse"))
	   {
		   ArrayList<TrueAndFalse>questions=new ArrayList<TrueAndFalse>();
		   for(int i=0;i<NumOfQuestions;i++)
		   {
			   TrueAndFalse q=new TrueAndFalse();
			   System.out.println("Enter the statment ");
			   q.setStatment(sc.nextLine());        //statment
			   System.out.println("Enter the correct answer");
			   q.setCorrectAnswer(sc.nextBoolean());
			   questions.add(q);
		   }
		  g.setTFQuestions(questions);
		   System.out.println("Enter name for the game");
		   g.setName(sc.nextLine());
		   System.out.println("Enter description to the game");
		   g.setDescrition(sc.nextLine());
		   
	   }
   }*/
	   public ArrayList<ArrayList<String>> DisplayGame (String category)
	   {
		   Database DB= new Database();
		   ArrayList<ArrayList<String>>games=new ArrayList<ArrayList<String>>();
		   if(category.equals("Science"))
		   {
			   ArrayList<String>tf=new ArrayList<String>();
			   ArrayList<String> mcq = new ArrayList<String>();
			   for(int i=0;i<DB.ScienceTF.size();i++)
			   {
				   tf.add(DB.ScienceTF.get(i).getName());
			   }
			   for(int j=0;j<DB.ScienceMCQ.size();j++)
			   {
				   mcq.add(DB.ScienceMCQ.get(j).getName());
			   }
			   games.add(tf);
			   games.add(mcq);
		   }
		   else if(category.equals("Math"))
		   {
			   ArrayList<String>tf=new ArrayList<String>();
			   ArrayList<String> mcq = new ArrayList<String>();
			   for(int i=0;i<DB.MathTF.size();i++)
			   {
				   tf.add(DB.MathTF.get(i).getName());
			   }
			   for(int j=0;j<DB.MathMCQ.size();j++)
			   {
				   mcq.add(DB.MathMCQ.get(j).getName());
			   }
			   games.add(tf);
			   games.add(mcq);
		   }
		   else if(category.equals("Code"))
		   {

			   ArrayList<String>tf=new ArrayList<String>();
			   ArrayList<String> mcq = new ArrayList<String>();
			   for(int i=0;i<DB.CodeTF.size();i++)
			   {
				   tf.add(DB.CodeTF.get(i).getName());
			   }
			   for(int j=0;j<DB.CodeMCQ.size();j++)
			   {
				   mcq.add(DB.CodeMCQ.get(j).getName());
			   }
			   games.add(tf);
			   games.add(mcq);   
		   }
		   else if(category.equals("Tech"))
		   {
			   ArrayList<String>tf=new ArrayList<String>();
			   ArrayList<String> mcq = new ArrayList<String>();
			   for(int i=0;i<DB.TechTF.size();i++)
			   {
				   tf.add(DB.TechTF.get(i).getName());
			   }
			   for(int j=0;j<DB.TechMCQ.size();j++)
			   {
				   mcq.add(DB.TechMCQ.get(j).getName());
			   }
			   games.add(tf);
			   games.add(mcq);
		   }
		  
		   return games;
	   }
	   
	   
	  
		   
		   
		
		   
		  
}
