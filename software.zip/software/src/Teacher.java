import java.util.ArrayList;


public class Teacher extends User{
	private String id;
	private ArrayList<Game> AddedGames;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ArrayList<Game> getAddedGames() {
		return AddedGames;
	}
	public void setAddedGame(Game g) {
		AddedGames.add(g);
	}
	
	

}
