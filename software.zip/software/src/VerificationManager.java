import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class VerificationManager { 
	
	Database DB=new Database();
	String user;
	public boolean VerfiyStudent(StudentRegisterationForm f)
	{
		if(EmailFormatIsRight(f.getEmail()))
		{
			for(int i=0;i<DB.students.size();i++)
			{
				if(DB.students.get(i).getEmali().equals(f.getEmail()))
				{
					System.out.println("Email is registered before");
					return false;
				}
			}
		}
		if(!(f.getPassword().equals(f.getConfirmedPassword())))
		{
			System.out.println("Confirmed password dose not match");
			return false;
		}
		else
		return true;
	}
	public boolean VerifyTeacher(TeacherRegisterationForm f ){///verify registration data
		String str = null;
		str=f.getId().substring(0,4);
		System.out.println(str);
		if(EmailFormatIsRight(f.getEmail())&&str.equals("2014")){
			System.out.println(DB.teachers.size());
				for(int i=0; i<DB.teachers.size(); i++){
					System.out.println("teacher for loop ");
					if(DB.teachers.get(i).getEmali().equals(f.getEmail())){
						System.out.println("teacher size "+DB.teachers.size());
						System.out.println("Email is registered before");
						return false;
					}
					//if(DB.teachers.get(i).equals("teacher")){
					 if(DB.teachers.get(i).getId().equals(f.getId())){
						System.out.println("ID is registered before");
						return false;
					}
					
				//}
					//return true;
				}
				}
		return true;
		
			
		
		
	
	}
	
	public boolean EmailFormatIsRight(String email){
		Pattern p=Pattern.compile("@", Pattern.CASE_INSENSITIVE);
		Matcher m= p.matcher(email);
		boolean b=m.find();
		
		Pattern p2=Pattern.compile(".com",Pattern.CASE_INSENSITIVE);
		Matcher m2=p2.matcher(email);
		boolean b2=m2.find();
		
		Pattern p3=Pattern.compile("gmail",Pattern.CASE_INSENSITIVE);
		Matcher m3=p3.matcher(email);
		boolean b3=m3.find();
		
		Pattern p4=Pattern.compile("yahoo",Pattern.CASE_INSENSITIVE);
		Matcher m4=p4.matcher(email);
		boolean b4=m4.find();
		
		Pattern p5=Pattern.compile("hotmail",Pattern.CASE_INSENSITIVE);
		Matcher m5=p5.matcher(email);
		boolean b5=m5.find();
		
		if(b&&b2&&(b3||b4||b5)){
			System.out.println("right email");
			return true;
		}
		else{
			System.out.println("wrong");
			return false;
		}
		
	}
	
	public boolean VerifyLoginData(Form f){
		/*if(!EmailFormatIsRight(f.getEmail())){
			System.out.println("wrong Email");
		}*/
		
		//else{
	
			for(int i=0; i<DB.students.size(); i++){
	
				if(DB.students.get(i).getEmali().equals(f.getEmail())&&DB.students.get(i).getPassword().equals(f.getPassword())){
					user="student";
					return true;
				}
			}
			
			for(int i=0; i<DB.teachers.size(); i++){
				if(DB.teachers.get(i).getEmali().equals(f.getEmail())&&DB.teachers.get(i).getPassword().equals(f.getPassword())){
					user="teacher";
					return true;
				}
		
			}
		//}
		return false;
		
	}
}

