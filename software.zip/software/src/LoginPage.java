import java.util.Scanner;


public class LoginPage {
	VerificationManager v;
	RegisterationManager r;
	public LoginPage()
	{
		v=new VerificationManager();
		r=new RegisterationManager();
		System.out.println("Login");
		System.out.println("Register as student");
		System.out.println("Register as teacher");
	}
   public void WaitAction(String choice)
   {
	   if(choice.equals("Login"))
	   {
		   Form f=new Form();
		   do
		   {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter email");
		   f.setEmail(sc.nextLine());
		   System.out.println("Enter password");
		   f.setPassword(sc.nextLine());
		   
		   }
		   while(!v.VerifyLoginData(f));
		   
		System.out.println(" done");   
	   }
	   else if(choice.equals("Register as student"))
	   {
		   Scanner input=new Scanner(System.in);
		   StudentRegisterationForm f=new StudentRegisterationForm();
		   String n;
		  // n= input.nextLine(); 
		   do
		   {
		  System.out.println("Enter your name:");
		   f.setName(input.nextLine());
		  System.out.println("Enter your email:");
		  f.setEmail(input.nextLine());
		  System.out.println("Enter your phone number :");
		  f.setNumber(input.nextLine());
		  System.out.println("Enter your password:");
		  f.setPassword(input.nextLine());
		  System.out.println("Confirm your password");
		  f.setConfirmedPassword(input.nextLine());
		  }
		   while(!r.MakeRegisteration(f));
		   System.out.println(r.db.students);
		   System.out.println("regusteration done");
		   
	   }
	   else if(choice.equals("Register as teacher"))
	   {
		   Scanner input=new Scanner(System.in);
		   TeacherRegisterationForm f=new TeacherRegisterationForm();
		   String n;
		  // n= input.nextLine(); 
		   do
		   {
		  System.out.println("Enter your name:");
		   f.setName(input.nextLine());
		  System.out.println("Enter your email:");
		  f.setEmail(input.nextLine());
		  System.out.println("Enter your phone number :");
		  f.setNumber(input.nextLine());
		  System.out.println("Enter your id");
		  f.setId(input.nextLine());
		  System.out.println("Enter your password:");
		  f.setPassword(input.nextLine());
		  System.out.println("Confirm your password");
		  f.setConfirmedPassword(input.nextLine());
		  }
		   while(!r.MakeRegisteration(f));
		   System.out.println(r.db.students);
		   System.out.println("regusteration done");
		   
	   }
	   
	   
		   
	   
   }
   public HomePage GetNextPage()
   {
	   HomePage page=null;
	   if(v.user.equals("student"))
	   {
		   page=new StudentHomePage();
	   }
	   else if(v.user.equals("teacher"))
	   {
		   page=new TeacherHomePage();
	   }
	   return page;
   }

}
