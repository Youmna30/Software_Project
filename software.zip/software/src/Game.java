import java.util.ArrayList;


public class Game {
	private String name;
	private String descrition;
	private float score=0;
	private int NumberOfStudentPlayed;
	private ArrayList<TrueAndFalse> TFquestions=new ArrayList<TrueAndFalse>();
	private ArrayList<MCQ> MCQquestions=new ArrayList<MCQ>();
	
	public ArrayList<MCQ> getMCQquestions() {
		return MCQquestions;
	}
	public void setMCQquestions(ArrayList<MCQ> mCQquestions) {
		MCQquestions = mCQquestions;
	}
	public void setTFQuestions(ArrayList<TrueAndFalse> questions) {
		this.TFquestions = questions;
	}
	private int NumOfQuestion;
	
	public ArrayList<TrueAndFalse> getTFQuestions() {
		return TFquestions;
	}
	/*public void setQuestion(ArrayList<TrueAndFalse> question) {
		this.questions = question;
	}*/
	public int getNumOfQuestion() {
		return NumOfQuestion;
	}
	public void setNumOfQuestion(int numOfQuestion) {
		NumOfQuestion = numOfQuestion;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public int getNumberOfStudentPlayed() {
		return NumberOfStudentPlayed;
	}
	public void setNumberOfStudentPlayed(int numberOfStudentPlayed) {
		NumberOfStudentPlayed = numberOfStudentPlayed;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescrition() {
		return descrition;
	}
	public void setDescrition(String descrition) {
		this.descrition = descrition;
	}
	

}
