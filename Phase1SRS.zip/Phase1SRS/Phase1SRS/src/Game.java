
public abstract class Game
{
	protected  String Question, Name;
	private char Answer;
	
	public void viewQuestion(){}
	
	public void setQuestion(String statment){}
	
	public void setQuestion (String statment, String ch[]){}

	
	public void setName(String name)
	{
		Name = name;
	}
	
	public String getName()
	{
		return Name;
	}
	
	public void setAnswer(char ans)
	{
		Answer = ans;
	}
		
	public void checkAnswer(char ans)
	{
		if(ans == Answer)
			System.out.println("True");
		else
			System.out.println("False");
	}	
}
