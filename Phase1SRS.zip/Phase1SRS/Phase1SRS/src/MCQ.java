
public class MCQ extends Game
{
	String choices[];
	
	public void setQuestion (String statment, String ch[])
	{
		Question = statment;
		choices = ch;
	}
	
	public void viewQuestion()
	{
		System.out.println("\nMCQ\n");
		System.out.println(Question);
		
		System.out.print("\na-" + choices[0] + "\nb-" + choices[1] + "\nc-" + choices[2] +
							"\nd-" + choices[3] + "Enetr answer character : ");
	}
}
