import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class GUITest {
	private GUI g;
	private Authentication a;
	   private Account ac;

	@Before
	public void setUp() throws Exception {
		g=new GUI();
		a=new Authentication();
		ac=new Account("yomna","yomna@gmail.com","1234567890","4th rabi`",-1);
	}

	@Test
	public void testSignIn() {
		a.CreateNewUser(ac, 2);
		assertEquals(-1,a.AuthenticateUser("yomna", "1234567890"));

	}

	@Test
	public void testSignUp() {
	g.name="yomna";
	g.email="yomna@gmail.com";
	g.age=-20;
	g.EL="college";
	g.G=3.1;
	g.address="4 rabi` street";
	g.password="1234567890";
	g.choice2=1;
	g.SignUp();
	
	int size=g.UserControl.Users.size();
	boolean x=size==0;
	assertEquals(0,size);
	
	
	}

}
