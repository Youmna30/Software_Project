import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AuthenticationTest {

   private Authentication a;
   private Account ac;

	@Before
	public void setUp() throws Exception {
		a=new Authentication();
		ac=new Account("yomna","yomna@gmail.com","1234567890","4th rabi`",21);
	}

	

	@Test
	public void testCreateNewUser() {
		a.CreateNewUser(ac, 3);
		int size=a.Users.size();
		assertEquals(size-1, size);
	}

	@Test
	public void testAuthenticateUser() {
		
		int size=a.Users.size();
		assertEquals(-1,a.AuthenticateUser("yomna", "1234567890"));
	}
}
