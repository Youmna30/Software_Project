import java.util.Scanner;

public class Teacher implements User
{
	static Teacher runner = new Teacher();
	Account TeAccount = new TeacherAccount();
	Scanner in = new Scanner(System.in);
	int choice;

	public void ViewUserHomePage()
	{		
		System.out.print("\n1-Create Game\n2-Sign Out\n\nEnter your choice : ");
		
		choice = in.nextInt();
		in.nextLine();
		
		switch (choice)
		{
			case 1:
				runner.CreateGame();
				break;
			case 2:
				return ;
			default:
				System.out.println("You enter invalid choice ..... please try again");				
		}
		
		runner.ViewUserHomePage();
	}
	
	public void SetAccount(Account UserAccount)
	{
		TeAccount = UserAccount;
	}
	
	public Account getAccount() 
	{
		return TeAccount;
	}

	public void CreateGame()
	{
		System.out.print("1-True and False\n2-MCQ\n\nEnter your choice : ");
		
		choice = in.nextInt();
		in.nextLine();
		
		switch (choice)
		{
			case 1:
				runner.CreateTFGame();
				break;
				
			case 2:
				runner.CreateMCQGame();
				break;
				
			default:
				System.out.println("You enter invalid choice .... please try again");
				runner.CreateGame();
		}
	}
	
	public void CreateTFGame()
	{
		String Question, Name;
		char Answer;
		Game Ngame = new TrueAndFalse();
		
		System.out.println("Please enter the following information\n");
		
		System.out.print("Name : ");
		Name = in.nextLine();
		Ngame.setName(Name);

		
		System.out.print("Question : ");
		Question = in.nextLine();
		Ngame.setQuestion(Question);
		
		System.out.print("Answer : ");
		Answer = in.nextLine().charAt(0);
		Ngame.setAnswer(Answer);

		GameControl.addGame(Ngame);
	}
	
	public void CreateMCQGame()
	{
		String Question, Name, choices[] = new String [4];
		char Answer;
		Game Ngame = new MCQ();
		
		System.out.println("Please enter the following information\n");
		
		System.out.print("Name : ");
		Name = in.nextLine();
		Ngame.setName(Name);

		
		System.out.print("Question : ");
		Question = in.nextLine();
		
		for (int i=1 ; i<5 ; i++)
		{
			System.out.print("choice #" + i + " : ");
			choices[i-1] = in.nextLine();
		}
		
		Ngame.setQuestion(Question, choices);
		
		System.out.print("Answer : ");
		Answer = in.nextLine().charAt(0);
		Ngame.setAnswer(Answer);
		
		GameControl.addGame(Ngame);
	}
}
