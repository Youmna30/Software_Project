import java.util.ArrayList;

public class Authentication 
{
	ArrayList <User> Users = new ArrayList <User>();
	
	public int AuthenticateUser(String Email, String password)
	{		
		for(int i=0 ; i<Users.size() ; i++)
		{
			if (Users.get(i).getAccount().getEmail().equals(Email)
					&& Users.get(i).getAccount().getPassword().equals(password))
			{
				return i;
			}
		}
		
		return -1;
	}
			
	public void FindUser (int ID)
	{
		Users.get(ID).ViewUserHomePage();
	}
	
	public void CreateNewUser (Account ac, int type)
	{
		User Nuser;

		if(type == 1)
			Nuser = new Student();
		else 
			Nuser = new Teacher();
		
		Nuser.SetAccount(ac);
		
		Users.add(Nuser);
		
		System.out.println("You have registered successfully");
	}
}
