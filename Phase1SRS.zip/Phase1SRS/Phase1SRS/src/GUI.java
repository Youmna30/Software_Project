
import java.util.Scanner;

public class GUI 
{
	int choice,choice2;
	static GUI runner = new GUI();
	Scanner in = new Scanner(System.in);
	Authentication UserControl = new Authentication();
	///-----------
	String name, email, password, address, EL;
	int age;
	double G;
	Account account;
	
	public static void main (String arg[])
	{
		runner.ShowHomePage();
	}
	
	public void ShowHomePage ()
	{		
		System.out.print("\n1-Sign in\n2-Sign up\n3-Exit\n\nEnter your choice : ");
		
		choice = in.nextInt();
		in.nextLine();
		
		switch (choice)
		{
			case 1 :
				runner.SignIn();
				break;
				
			case 2:
				runner.SignUp();
				break;
				
			case 3:
				return;
				
			default:
				System.out.println("You enter invalid choice ..... please try again");
		}
		
		runner.ShowHomePage();
	}
	
	public void SignIn()
	{
		String mail, pass;
		int ID;
		
		System.out.print("Please enter you E-mail and Password\n\nE-mail : ");
		
		mail = in.nextLine();
		
		System.out.print("Password : ");
		
		pass = in.nextLine();
		
		ID = UserControl.AuthenticateUser(mail, pass);
		
		if(ID == -1)
		{
			System.out.println("You enter invalid E-mail or Password .... please try again");
			runner.SignIn();
		}
		
		else
		{
			UserControl.FindUser(ID);
		}
	}
	
	public void SignUp()
	{
		//System.out.print("\n1-Student\n2-Teacher\n\nEnter your choice : ");
		
		//choice2 = in.nextInt();
		//in.nextLine();
		
		switch (choice2)
		{
			case 1:
				StudentRegister();
				break;
				
			case 2:
				runner.TeacherRegister();
				break;
				
			default:
				System.out.println("You enter invalid choice ...... please try again");
				runner.SignUp();
		}		
	}
	
	public void StudentRegister()
	{
		

		System.out.println("Please enter the following information");
		
	/*	System.out.print("Name : ");
		name = in.nextLine();
		
		System.out.print("E-mail : ");
		email = in.nextLine();
		
		System.out.print("Password : ");
		password = in.nextLine();
		
		System.out.print("Address : ");
		address = in.nextLine();
		
		System.out.print("Age : ");
		age = in.nextInt();
		in.nextLine();
		
		System.out.print("Educational Level : ");
		EL = in.nextLine();
		
		System.out.print("Grade : ");
		G = in.nextDouble();
		in.nextLine();*/
		
		account = new StudentAccount(name,email,password,address,age,EL,G);
		UserControl.CreateNewUser(account,1);
	}
	
	public void TeacherRegister()
	{
		String name, email, password, address, D;
		int age, YOE;
		Account account;

		System.out.println("Please enter the following information");
		
		System.out.print("Name : ");
		name = in.nextLine();
		
		System.out.print("E-mail : ");
		email = in.nextLine();
		
		System.out.print("Password : ");
		password = in.nextLine();
		
		System.out.print("Address : ");
		address = in.nextLine();
		
		System.out.print("Age : ");
		age = in.nextInt();
		in.nextLine();

		System.out.print("Degree : ");
		D = in.nextLine();
		
		System.out.print("YearsOfExperiance : ");
		YOE = in.nextInt();
		in.nextLine();

		account = new TeacherAccount(name,email,password,address,age,D,YOE);
		UserControl.CreateNewUser(account,2);
	}
}
             