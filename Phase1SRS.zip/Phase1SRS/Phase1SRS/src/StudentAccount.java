
public class StudentAccount extends Account
{
	String EducationalLevel;
	double Grade;
	
	public StudentAccount()
	{
		
	}
	
	public StudentAccount(String name, String mail, String pass, String address, int age, 
								String EL, double grade)
	{
		super(name, mail, pass, address, age);
		
		EducationalLevel = EL;
		Grade = grade;
	}
}
