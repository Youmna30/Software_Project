
public class TrueAndFalse extends Game
{
	public void setQuestion (String statment)
	{
		Question = statment;
	}
	
	public void viewQuestion()
	{
		System.out.println("\nTrue or False\n");
		System.out.println(Question);
		System.out.print("\nEnter 'T' for true or 'F' for false : ");
	}
}
