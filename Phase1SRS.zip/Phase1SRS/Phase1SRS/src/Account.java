
public class Account
{
	private String Name, Email, Password, Address;
	private int Age;
	
	public Account ()
	{
		
	}
	
	public Account(String name, String mail, String pass, String address, int age)
	{
		Name = name;		 Email = mail;
		Address = address;	 Age = age;
		Password = pass;
	}
	
	public String getName()
	{
		return Name;
	}
	
	public String getPassword()
	{
		return Password;
	}
	
	public String getEmail()
	{
		return Email;
	}
	
	public String getAddress()
	{
		return Address;
	}
	
	public int getAge()
	{
		return Age;
	}
}
