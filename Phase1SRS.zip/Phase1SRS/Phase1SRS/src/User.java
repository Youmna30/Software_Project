
public interface User 
{
	public GameController GameControl = new GameController();
	
	public void ViewUserHomePage();
	public void SetAccount (Account UserAccount);
	public Account getAccount();
}
