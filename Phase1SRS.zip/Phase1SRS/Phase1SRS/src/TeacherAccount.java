
public class TeacherAccount extends Account
{
	String Degree;
	int YearsOfExperiance;
	
	public TeacherAccount()
	{
		
	}
	
	public TeacherAccount(String name, String mail, String pass, String address, int age,
								String degree, int YOE)
	{
		super(name, mail, pass, address, age);
		
		Degree = degree;
		YearsOfExperiance = YOE;
	}
}
