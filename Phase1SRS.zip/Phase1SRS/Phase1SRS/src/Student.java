import java.util.Scanner;

public class Student implements User
{
	static Student runner = new Student();
	Account StAccount = new StudentAccount();
	Scanner in = new Scanner(System.in);
	int choice;
	
	public void ViewUserHomePage() 
	{		
		System.out.print("\n1-Play Game\n2-Sign Out\n\nEnter your choice : ");
		
		choice = in.nextInt();
		in.nextLine();
		
		switch (choice)
		{
			case 1:
				runner.PlayGame();
				break;
			case 2:
				return ;
			default:
				System.out.println("You enter invalid choice ..... please try again");				
		}
		
		runner.ViewUserHomePage();
	}
	
	public void SetAccount(Account UserAccount)
	{
		StAccount = UserAccount;
	}
	
	public Account getAccount()
	{
		return StAccount;
	}
	
	public void PlayGame()
	{
		char ans;
		
		GameControl.ViewGames();
		
		System.out.print("Enter your choice : ");
		
		choice = in.nextInt();
		in.nextLine();
		
		GameControl.findGame(choice);
		
		ans = in.nextLine().charAt(0);
		
		GameControl.checkGameAnswer(choice, ans);
	}
}
