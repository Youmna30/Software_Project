import java.util.ArrayList;

public class GameController
{
	private ArrayList <Game> Games = new ArrayList<Game>();
	
	public void ViewGames ()
	{
		for(int i=0 ; i<Games.size() ; i++)
		{
			System.out.println(i+1 + "-" + Games.get(i).getName());
		}
	}
	
	public void findGame (int ID)
	{
		if(ID<=0 || ID>Games.size())
			System.out.println("No such game!!");
		
		else
			Games.get(ID-1).viewQuestion();
	}
	
	public void checkGameAnswer (int ID, char ans)
	{
		if(ID<=0 || ID>Games.size())
			System.out.println("No such game!!");
		
		else
			Games.get(ID-1).checkAnswer(ans);
	}
	
	public void addGame (Game Ngame)
	{
		Games.add(Ngame);
		System.out.println("You have craeted the game successfully");
	}
}
