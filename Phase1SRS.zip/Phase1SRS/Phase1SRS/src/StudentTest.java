
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class StudentTest {
 
	private Student s;
	private GameController gc;
	private Teacher t;
	@Before
	public void setUp() throws Exception {
		s=new Student();
		gc=new GameController();
		t=new Teacher();
		
	}

	

}
