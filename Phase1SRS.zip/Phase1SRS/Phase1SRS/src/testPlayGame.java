import static org.junit.Assert.*;

import org.junit.Test;

public class testPlayGame {

	@Test
	public void testPlayGame() {
		char ans;
		GameController gamer=new GameController();
		gamer.ViewGames();
		gamer.findGame(1);
		gamer.checkGameAnswer(1, 'f');
		Student s=new Student();
		s.PlayGame();
		assertEquals('f', 't');
	}

}
